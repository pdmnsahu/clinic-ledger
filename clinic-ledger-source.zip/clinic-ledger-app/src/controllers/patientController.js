const { db } = require('../models/database');

const getAll = (req, res) => {
  const { search, page = 1, limit = 50 } = req.query;
  const offset = (Number(page) - 1) * Number(limit);
  let query = 'SELECT * FROM patients';
  let countQuery = 'SELECT COUNT(*) as total FROM patients';
  const params = [];
  if (search) {
    query += ' WHERE name LIKE ? OR phone LIKE ? OR email LIKE ?';
    countQuery += ' WHERE name LIKE ? OR phone LIKE ? OR email LIKE ?';
    const s = `%${search}%`;
    params.push(s, s, s);
  }
  query += ' ORDER BY name ASC LIMIT ? OFFSET ?';
  const patients = db.prepare(query).all(...params, Number(limit), offset);
  const { total } = db.prepare(countQuery).get(...params);
  res.json({ patients, total, page: Number(page), limit: Number(limit) });
};

const getOne = (req, res) => {
  const patient = db.prepare('SELECT * FROM patients WHERE id = ?').get(req.params.id);
  if (!patient) return res.status(404).json({ error: 'Patient not found' });
  const visits = db.prepare(`
    SELECT v.*, COALESCE((SELECT SUM(amount) FROM payments WHERE visit_id = v.id), 0) as paid_amount
    FROM visits v WHERE v.patient_id = ? ORDER BY v.created_at DESC LIMIT 10
  `).all(req.params.id);
  const stats = db.prepare(`
    SELECT COUNT(DISTINCT v.id) as total_visits, COALESCE(SUM(v.net_amount),0) as total_billed, COALESCE(SUM(p.paid),0) as total_paid
    FROM visits v LEFT JOIN (SELECT visit_id, SUM(amount) as paid FROM payments GROUP BY visit_id) p ON p.visit_id=v.id
    WHERE v.patient_id = ?
  `).get(req.params.id);
  res.json({ ...patient, visits, stats });
};

const create = (req, res) => {
  const { name, phone, email, address, notes } = req.body;
  if (!name?.trim()) return res.status(400).json({ error: 'Patient name is required' });
  const result = db.prepare('INSERT INTO patients (name, phone, email, address, notes) VALUES (?, ?, ?, ?, ?)').run(name.trim(), phone || null, email || null, address || null, notes || null);
  res.status(201).json(db.prepare('SELECT * FROM patients WHERE id = ?').get(result.lastInsertRowid));
};

const update = (req, res) => {
  const { name, phone, email, address, notes } = req.body;
  if (!name?.trim()) return res.status(400).json({ error: 'Patient name is required' });
  const existing = db.prepare('SELECT id FROM patients WHERE id = ?').get(req.params.id);
  if (!existing) return res.status(404).json({ error: 'Patient not found' });
  db.prepare('UPDATE patients SET name=?, phone=?, email=?, address=?, notes=?, updated_at=CURRENT_TIMESTAMP WHERE id=?').run(name.trim(), phone || null, email || null, address || null, notes || null, req.params.id);
  res.json(db.prepare('SELECT * FROM patients WHERE id = ?').get(req.params.id));
};

const remove = (req, res) => {
  const existing = db.prepare('SELECT id FROM patients WHERE id = ?').get(req.params.id);
  if (!existing) return res.status(404).json({ error: 'Patient not found' });
  const hasVisits = db.prepare('SELECT id FROM visits WHERE patient_id = ?').get(req.params.id);
  if (hasVisits) return res.status(400).json({ error: 'Cannot delete patient with existing visits' });
  db.prepare('DELETE FROM patients WHERE id = ?').run(req.params.id);
  res.json({ success: true });
};

module.exports = { getAll, getOne, create, update, remove };
