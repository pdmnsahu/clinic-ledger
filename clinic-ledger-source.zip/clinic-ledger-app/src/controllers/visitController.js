const { db } = require('../models/database');
function generateVisitNumber() {
  const now = new Date();
  return `CL-${String(now.getFullYear()).slice(-2)}${String(now.getMonth()+1).padStart(2,'0')}-${Math.floor(1000 + Math.random()*9000)}`;
}
const getAll = (req, res) => {
  const { search, status, patient_id, from, to, page = 1, limit = 50 } = req.query;
  const params = []; const where = [];
  if (search) { where.push('(v.visit_number LIKE ? OR v.description LIKE ? OR p.name LIKE ?)'); const s=`%${search}%`; params.push(s,s,s); }
  if (status) { where.push('v.status = ?'); params.push(status); }
  if (patient_id) { where.push('v.patient_id = ?'); params.push(patient_id); }
  if (from) { where.push('DATE(v.created_at) >= ?'); params.push(from); }
  if (to) { where.push('DATE(v.created_at) <= ?'); params.push(to); }
  const whereStr = where.length ? 'WHERE ' + where.join(' AND ') : '';
  const offset = (Number(page)-1) * Number(limit);
  const visits = db.prepare(`SELECT v.*, p.name as patient_name, COALESCE((SELECT SUM(amount) FROM payments WHERE visit_id=v.id),0) as paid_amount, v.net_amount - COALESCE((SELECT SUM(amount) FROM payments WHERE visit_id=v.id),0) as due_amount FROM visits v JOIN patients p ON p.id=v.patient_id ${whereStr} ORDER BY v.created_at DESC LIMIT ? OFFSET ?`).all(...params, Number(limit), offset);
  const { total } = db.prepare(`SELECT COUNT(*) as total FROM visits v JOIN patients p ON p.id=v.patient_id ${whereStr}`).get(...params);
  res.json({ visits, total, page: Number(page), limit: Number(limit) });
};
const getOne = (req, res) => {
  const visit = db.prepare(`SELECT v.*, p.name as patient_name, p.phone as patient_phone, COALESCE((SELECT SUM(amount) FROM payments WHERE visit_id=v.id),0) as paid_amount, v.net_amount - COALESCE((SELECT SUM(amount) FROM payments WHERE visit_id=v.id),0) as due_amount FROM visits v JOIN patients p ON p.id=v.patient_id WHERE v.id = ?`).get(req.params.id);
  if (!visit) return res.status(404).json({ error: 'Visit not found' });
  const payments = db.prepare('SELECT * FROM payments WHERE visit_id = ? ORDER BY paid_at DESC').all(req.params.id);
  res.json({ ...visit, payments });
};
const create = (req, res) => {
  const { patient_id, description, visit_type, quantity, unit_price, discount, status, due_date, notes, advance_amount, advance_method, advance_reference } = req.body;
  if (!patient_id) return res.status(400).json({ error: 'Patient is required' });
  if (!description?.trim()) return res.status(400).json({ error: 'Visit description is required' });
  if (!unit_price || isNaN(unit_price)) return res.status(400).json({ error: 'Valid consultation fee is required' });
  const qty = Number(quantity) || 1; const price = Number(unit_price); const disc = Number(discount) || 0; const total = qty * price; const net = total - disc;
  if (net < 0) return res.status(400).json({ error: 'Discount cannot exceed total amount' });
  const advance = Number(advance_amount) || 0;
  if (advance > net + 0.01) return res.status(400).json({ error: `Advance cannot exceed visit amount of ₹${net.toFixed(2)}` });
  const tx = db.transaction(() => {
    const result = db.prepare('INSERT INTO visits (patient_id, visit_number, description, visit_type, quantity, unit_price, total_amount, discount, net_amount, status, due_date, notes) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)').run(patient_id, generateVisitNumber(), description.trim(), visit_type || null, qty, price, total, disc, net, status || 'scheduled', due_date || null, notes || null);
    const visitId = result.lastInsertRowid;
    if (advance > 0) {
      db.prepare('INSERT INTO payments (visit_id, patient_id, amount, payment_method, reference_no, notes, paid_at) VALUES (?, ?, ?, ?, ?, ?, ?)').run(visitId, patient_id, advance, advance_method || 'cash', advance_reference || null, 'Advance payment', new Date().toISOString());
      if (advance >= net - 0.01) db.prepare("UPDATE visits SET status='billed', updated_at=CURRENT_TIMESTAMP WHERE id=?").run(visitId);
    }
    return visitId;
  });
  const visitId = tx();
  res.status(201).json(db.prepare('SELECT * FROM visits WHERE id = ?').get(visitId));
};
const update = (req, res) => {
  const existing = db.prepare('SELECT * FROM visits WHERE id = ?').get(req.params.id);
  if (!existing) return res.status(404).json({ error: 'Visit not found' });
  const { patient_id, description, visit_type, quantity, unit_price, discount, status, due_date, notes } = req.body;
  if (!description?.trim()) return res.status(400).json({ error: 'Visit description is required' });
  if (!unit_price || isNaN(unit_price)) return res.status(400).json({ error: 'Valid consultation fee is required' });
  const qty = Number(quantity) || 1; const price = Number(unit_price); const disc = Number(discount) || 0; const total = qty * price; const net = total - disc;
  db.prepare('UPDATE visits SET patient_id=?, description=?, visit_type=?, quantity=?, unit_price=?, total_amount=?, discount=?, net_amount=?, status=?, due_date=?, notes=?, updated_at=CURRENT_TIMESTAMP WHERE id=?').run(patient_id || existing.patient_id, description.trim(), visit_type || null, qty, price, total, disc, net, status || existing.status, due_date || null, notes || null, req.params.id);
  res.json(db.prepare('SELECT * FROM visits WHERE id = ?').get(req.params.id));
};
const remove = (req, res) => { const existing = db.prepare('SELECT id FROM visits WHERE id = ?').get(req.params.id); if (!existing) return res.status(404).json({ error: 'Visit not found' }); db.prepare('DELETE FROM visits WHERE id = ?').run(req.params.id); res.json({ success: true }); };
const addPayment = (req, res) => {
  const visit = db.prepare('SELECT v.*, COALESCE((SELECT SUM(amount) FROM payments WHERE visit_id=v.id),0) as paid_amount FROM visits v WHERE id = ?').get(req.params.id);
  if (!visit) return res.status(404).json({ error: 'Visit not found' });
  const { amount, payment_method, reference_no, notes, paid_at } = req.body;
  if (!amount || isNaN(amount) || Number(amount) <= 0) return res.status(400).json({ error: 'Valid payment amount is required' });
  const remaining = visit.net_amount - visit.paid_amount;
  if (Number(amount) > remaining + 0.01) return res.status(400).json({ error: `Payment exceeds due amount of ₹${remaining.toFixed(2)}` });
  const result = db.prepare('INSERT INTO payments (visit_id, patient_id, amount, payment_method, reference_no, notes, paid_at) VALUES (?, ?, ?, ?, ?, ?, ?)').run(req.params.id, visit.patient_id, Number(amount), payment_method || 'cash', reference_no || null, notes || null, paid_at || new Date().toISOString());
  if (visit.paid_amount + Number(amount) >= visit.net_amount - 0.01) db.prepare("UPDATE visits SET status='billed', updated_at=CURRENT_TIMESTAMP WHERE id=?").run(req.params.id);
  res.status(201).json(db.prepare('SELECT * FROM payments WHERE id = ?').get(result.lastInsertRowid));
};
const deletePayment = (req, res) => { const payment = db.prepare('SELECT * FROM payments WHERE id = ?').get(req.params.paymentId); if (!payment) return res.status(404).json({ error: 'Payment not found' }); db.prepare('DELETE FROM payments WHERE id = ?').run(req.params.paymentId); res.json({ success: true }); };
module.exports = { getAll, getOne, create, update, remove, addPayment, deletePayment };
