const { db } = require('../models/database');
const dashboard = (req, res) => {
  const today = new Date().toISOString().split('T')[0]; const monthStart = today.slice(0, 7) + '-01';
  const stats = {
    total_patients: db.prepare('SELECT COUNT(*) as c FROM patients').get().c,
    total_visits: db.prepare('SELECT COUNT(*) as c FROM visits').get().c,
    pending_visits: db.prepare("SELECT COUNT(*) as c FROM visits WHERE status IN ('scheduled','in_consultation','completed')").get().c,
    total_collected: db.prepare('SELECT COALESCE(SUM(amount),0) as s FROM payments').get().s,
    month_payments: db.prepare('SELECT COALESCE(SUM(amount),0) as s FROM payments WHERE DATE(paid_at) >= ?').get(monthStart).s,
    total_billed: db.prepare('SELECT COALESCE(SUM(net_amount),0) as s FROM visits').get().s,
    total_dues: db.prepare(`SELECT COALESCE(SUM(v.net_amount - COALESCE(p.paid,0)),0) as s FROM visits v LEFT JOIN (SELECT visit_id, SUM(amount) as paid FROM payments GROUP BY visit_id) p ON p.visit_id=v.id WHERE v.status NOT IN ('cancelled')`).get().s,
    total_expense: db.prepare('SELECT COALESCE(SUM(amount),0) as s FROM expenses').get().s,
    month_expense: db.prepare('SELECT COALESCE(SUM(amount),0) as s FROM expenses WHERE expense_date >= ?').get(monthStart).s,
    total_purchase: db.prepare('SELECT COALESCE(SUM(amount),0) as s FROM purchases').get().s,
    month_purchase: db.prepare('SELECT COALESCE(SUM(amount),0) as s FROM purchases WHERE purchase_date >= ?').get(monthStart).s,
  };
  stats.total_outgoing = stats.total_expense + stats.total_purchase;
  stats.month_outgoing = stats.month_expense + stats.month_purchase;
  stats.net_profit = stats.total_collected - stats.total_outgoing;
  stats.month_profit = stats.month_payments - stats.month_outgoing;
  const recent_visits = db.prepare('SELECT v.*, p.name as patient_name, COALESCE((SELECT SUM(amount) FROM payments WHERE visit_id=v.id),0) as paid_amount FROM visits v JOIN patients p ON p.id=v.patient_id ORDER BY v.created_at DESC LIMIT 8').all();
  const pending_dues = db.prepare(`SELECT p.name as patient_name, COUNT(v.id) as visit_count, SUM(v.net_amount - COALESCE(pm.paid,0)) as due_amount FROM visits v JOIN patients p ON p.id=v.patient_id LEFT JOIN (SELECT visit_id, SUM(amount) as paid FROM payments GROUP BY visit_id) pm ON pm.visit_id=v.id WHERE v.status NOT IN ('cancelled','billed') AND (v.net_amount - COALESCE(pm.paid,0)) > 0 GROUP BY v.patient_id ORDER BY due_amount DESC LIMIT 8`).all();
  const recent_payments = db.prepare('SELECT pm.*, p.name as patient_name, v.visit_number FROM payments pm JOIN patients p ON p.id=pm.patient_id JOIN visits v ON v.id=pm.visit_id ORDER BY pm.paid_at DESC LIMIT 8').all();
  res.json({ stats, recent_visits, pending_dues, recent_payments });
};
const report = (req, res) => {
  const { period, from, to } = req.query; let startDate, endDate; const today = new Date();
  if (period === 'today') startDate = endDate = today.toISOString().split('T')[0];
  else if (period === 'week') { const d = new Date(today); d.setDate(d.getDate() - 6); startDate = d.toISOString().split('T')[0]; endDate = today.toISOString().split('T')[0]; }
  else if (period === 'custom' && from && to) { startDate = from; endDate = to; }
  else { startDate = today.toISOString().slice(0,7)+'-01'; endDate = today.toISOString().split('T')[0]; }
  const income_total = db.prepare('SELECT COALESCE(SUM(amount),0) as s FROM payments WHERE DATE(paid_at) BETWEEN ? AND ?').get(startDate, endDate).s;
  const expense_total = db.prepare('SELECT COALESCE(SUM(amount),0) as s FROM expenses WHERE expense_date BETWEEN ? AND ?').get(startDate, endDate).s;
  const purchase_total = db.prepare('SELECT COALESCE(SUM(amount),0) as s FROM purchases WHERE purchase_date BETWEEN ? AND ?').get(startDate, endDate).s;
  const outgoing_total = expense_total + purchase_total;
  const visits_count = db.prepare('SELECT COUNT(*) as c FROM visits WHERE DATE(created_at) BETWEEN ? AND ?').get(startDate, endDate).c;
  const visits_billed = db.prepare('SELECT COALESCE(SUM(net_amount),0) as s FROM visits WHERE DATE(created_at) BETWEEN ? AND ?').get(startDate, endDate).s;
  const expense_by_category = db.prepare('SELECT category, SUM(amount) as total FROM expenses WHERE expense_date BETWEEN ? AND ? GROUP BY category').all(startDate, endDate);
  const purchase_by_category = db.prepare('SELECT category, SUM(amount) as total FROM purchases WHERE purchase_date BETWEEN ? AND ? GROUP BY category').all(startDate, endDate);
  const daily_summary = db.prepare(`SELECT d.date, COALESCE(pm.payments, 0) as income, COALESCE(e.expense, 0) as expense, COALESCE(pu.purchase, 0) as purchase, COALESCE(pm.payments, 0) - COALESCE(e.expense, 0) - COALESCE(pu.purchase, 0) as net FROM (SELECT DISTINCT DATE(paid_at) as date FROM payments WHERE DATE(paid_at) BETWEEN ? AND ? UNION SELECT DISTINCT expense_date FROM expenses WHERE expense_date BETWEEN ? AND ? UNION SELECT DISTINCT purchase_date FROM purchases WHERE purchase_date BETWEEN ? AND ?) d LEFT JOIN (SELECT DATE(paid_at) as pd, SUM(amount) as payments FROM payments WHERE DATE(paid_at) BETWEEN ? AND ? GROUP BY pd) pm ON pm.pd=d.date LEFT JOIN (SELECT expense_date, SUM(amount) as expense FROM expenses WHERE expense_date BETWEEN ? AND ? GROUP BY expense_date) e ON e.expense_date=d.date LEFT JOIN (SELECT purchase_date, SUM(amount) as purchase FROM purchases WHERE purchase_date BETWEEN ? AND ? GROUP BY purchase_date) pu ON pu.purchase_date=d.date ORDER BY d.date`).all(startDate, endDate, startDate, endDate, startDate, endDate, startDate, endDate, startDate, endDate, startDate, endDate);
  const top_patients = db.prepare(`SELECT p.name, SUM(v.net_amount) as billed, COALESCE(SUM(pm.paid),0) as paid FROM visits v JOIN patients p ON p.id=v.patient_id LEFT JOIN (SELECT visit_id, SUM(amount) as paid FROM payments GROUP BY visit_id) pm ON pm.visit_id=v.id WHERE DATE(v.created_at) BETWEEN ? AND ? GROUP BY v.patient_id ORDER BY billed DESC LIMIT 10`).all(startDate, endDate);
  res.json({ period: { startDate, endDate }, summary: { income_total, expense_total, purchase_total, outgoing_total, visits_count, visits_billed, net_profit: income_total - outgoing_total }, expense_by_category, purchase_by_category, daily_summary, top_patients });
};
const exportCSV = (req, res) => {
  const { type, from, to } = req.query; let data, headers;
  if (type === 'visits') {
    data = db.prepare(`SELECT v.visit_number, p.name as patient, v.description, v.visit_type, v.quantity, v.unit_price, v.total_amount, v.discount, v.net_amount, COALESCE((SELECT SUM(amount) FROM payments WHERE visit_id=v.id),0) as paid, v.net_amount - COALESCE((SELECT SUM(amount) FROM payments WHERE visit_id=v.id),0) as due, v.status, v.due_date, v.created_at FROM visits v JOIN patients p ON p.id=v.patient_id ${from && to ? 'WHERE DATE(v.created_at) BETWEEN ? AND ?' : ''} ORDER BY v.created_at DESC`).all(...(from && to ? [from,to] : []));
    headers = ['visit_number','patient','description','visit_type','quantity','unit_price','total_amount','discount','net_amount','paid','due','status','due_date','created_at'];
  } else if (type === 'payments') {
    data = db.prepare(`SELECT pm.id, v.visit_number, p.name as patient, pm.amount, pm.payment_method, pm.reference_no, pm.paid_at, pm.notes FROM payments pm JOIN visits v ON v.id=pm.visit_id JOIN patients p ON p.id=pm.patient_id ${from && to ? 'WHERE DATE(pm.paid_at) BETWEEN ? AND ?' : ''} ORDER BY pm.paid_at DESC`).all(...(from && to ? [from,to] : []));
    headers = ['id','visit_number','patient','amount','payment_method','reference_no','paid_at','notes'];
  } else if (type === 'purchases') { data = db.prepare(`SELECT * FROM purchases ${from && to ? 'WHERE purchase_date BETWEEN ? AND ?' : ''} ORDER BY purchase_date DESC`).all(...(from && to ? [from,to] : [])); headers = ['id','title','amount','category','description','vendor','reference_no','purchase_date','created_at']; }
  else if (type === 'expenses') { data = db.prepare(`SELECT * FROM expenses ${from && to ? 'WHERE expense_date BETWEEN ? AND ?' : ''} ORDER BY expense_date DESC`).all(...(from && to ? [from,to] : [])); headers = ['id','title','amount','category','description','vendor','reference_no','expense_date','created_at']; }
  else if (type === 'patients') { data = db.prepare('SELECT * FROM patients ORDER BY name').all(); headers = ['id','name','phone','email','address','notes','created_at']; }
  else return res.status(400).json({ error: 'Invalid export type' });
  const csv = [headers.join(','), ...data.map(row => headers.map(h => { const val = row[h] != null ? String(row[h]) : ''; return val.includes(',') || val.includes('\"') || val.includes('\n') ? `\"${val.replace(/\"/g, '\"\"')}\"` : val; }).join(','))].join('\n');
  res.setHeader('Content-Type', 'text/csv');
  res.setHeader('Content-Disposition', `attachment; filename=${type}_${new Date().toISOString().split('T')[0]}.csv`);
  res.send(csv);
};
module.exports = { dashboard, report, exportCSV };
