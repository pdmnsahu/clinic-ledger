const { db } = require('../models/database');

const getAll = (req, res) => {
  const { search, category, from, to, page = 1, limit = 50 } = req.query;
  let where = [];
  const params = [];

  if (search) {
    where.push('(title LIKE ? OR description LIKE ? OR vendor LIKE ?)');
    const s = `%${search}%`;
    params.push(s, s, s);
  }
  if (category) { where.push('category = ?'); params.push(category); }
  if (from) { where.push('purchase_date >= ?'); params.push(from); }
  if (to) { where.push('purchase_date <= ?'); params.push(to); }

  const whereStr = where.length ? 'WHERE ' + where.join(' AND ') : '';
  const offset = (page - 1) * limit;

  const purchases = db.prepare(`SELECT * FROM purchases ${whereStr} ORDER BY purchase_date DESC, created_at DESC LIMIT ? OFFSET ?`).all(...params, Number(limit), Number(offset));
  const { total } = db.prepare(`SELECT COUNT(*) as total FROM purchases ${whereStr}`).get(...params);
  const { sum } = db.prepare(`SELECT COALESCE(SUM(amount),0) as sum FROM purchases ${whereStr}`).get(...params);

  res.json({ purchases, total, sum, page: Number(page), limit: Number(limit) });
};

const getOne = (req, res) => {
  const purchase = db.prepare('SELECT * FROM purchases WHERE id = ?').get(req.params.id);
  if (!purchase) return res.status(404).json({ error: 'Purchase not found' });
  res.json(purchase);
};

const create = (req, res) => {
  const { title, amount, category, description, vendor, reference_no, purchase_date } = req.body;
  if (!title?.trim()) return res.status(400).json({ error: 'Title is required' });
  if (!amount || isNaN(amount) || Number(amount) <= 0) return res.status(400).json({ error: 'Valid amount is required' });
  if (!purchase_date) return res.status(400).json({ error: 'Date is required' });

  const result = db.prepare(
    'INSERT INTO purchases (title, amount, category, description, vendor, reference_no, purchase_date) VALUES (?, ?, ?, ?, ?, ?, ?)'
  ).run(title.trim(), Number(amount), category || 'raw_materials', description || null, vendor || null, reference_no || null, purchase_date);

  res.status(201).json(db.prepare('SELECT * FROM purchases WHERE id = ?').get(result.lastInsertRowid));
};

const update = (req, res) => {
  const existing = db.prepare('SELECT id FROM purchases WHERE id = ?').get(req.params.id);
  if (!existing) return res.status(404).json({ error: 'Purchase not found' });

  const { title, amount, category, description, vendor, reference_no, purchase_date } = req.body;
  if (!title?.trim()) return res.status(400).json({ error: 'Title is required' });
  if (!amount || isNaN(amount) || Number(amount) <= 0) return res.status(400).json({ error: 'Valid amount is required' });
  if (!purchase_date) return res.status(400).json({ error: 'Date is required' });

  db.prepare(
    'UPDATE purchases SET title=?, amount=?, category=?, description=?, vendor=?, reference_no=?, purchase_date=?, updated_at=CURRENT_TIMESTAMP WHERE id=?'
  ).run(title.trim(), Number(amount), category || 'raw_materials', description || null, vendor || null, reference_no || null, purchase_date, req.params.id);

  res.json(db.prepare('SELECT * FROM purchases WHERE id = ?').get(req.params.id));
};

const remove = (req, res) => {
  const existing = db.prepare('SELECT id FROM purchases WHERE id = ?').get(req.params.id);
  if (!existing) return res.status(404).json({ error: 'Purchase not found' });
  db.prepare('DELETE FROM purchases WHERE id = ?').run(req.params.id);
  res.json({ success: true });
};

module.exports = { getAll, getOne, create, update, remove };
