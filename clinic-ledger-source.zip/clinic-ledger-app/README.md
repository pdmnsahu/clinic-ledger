# ClinicLedger

Small local-clinic management app built with Node.js, Express, SQLite, and a static multi-page frontend.
It keeps the original UI/workflow style while repurposing the domain for a clinic.

## Modules
- Patients
- Visits
- Payments against visits
- Expenses
- Medical supplies purchases
- Reports + CSV export

## Default login
- admin / admin123

## Run
```bash
npm install
npm start
```
